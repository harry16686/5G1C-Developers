class Customer:
    customer_id = 0
    customer_name = ''
    customer_phone = ''
    customer_address = ''
    customer_birthday = ''
    customer_occupation = ''
    customer_gender = ''

    def __init__(self):
        self.customer_id = 0
        self.customer_name = ''
        self.customer_phone = ''
        self.customer_address = ''
        self.customer_birthday = ''
        self.customer_occupation = ''
        self.customer_gender = ''
