class Store:
    store_id = 0
    store_name = ''
    store_address = ''
    store_phone = ''
    store_city = ''
    store_state = ''

    def __init__(self):
        self.store_id = 0
        self.store_name = ''
        self.store_address = ''
        self.store_phone = ''
        self.store_city = ''
        self.store_state = ''
