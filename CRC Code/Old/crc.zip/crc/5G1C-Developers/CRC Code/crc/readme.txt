1. 安装Mysql支持，下载安装包：https://files.pythonhosted.org/packages/a5/e9/51b544da85a36a68debe7a7091f068d802fc515a3a202652828c73453cad/MySQL-python-1.2.5.zip
sudo python setup.py install


2. run app
    python manage.py runserver 0.0.0.0:8000
    访问: http://localhost:8000/index
